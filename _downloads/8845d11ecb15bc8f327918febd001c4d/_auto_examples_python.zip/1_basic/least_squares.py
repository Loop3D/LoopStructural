"""
============================
1a. Advanced least squares
============================
This is an advanced tutorial to demonstrate how to get acces to the least squares matrices and add additional constraints into the system.
"""
