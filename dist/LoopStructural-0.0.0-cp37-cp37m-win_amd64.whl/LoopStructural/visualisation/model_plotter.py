# import pyvista as pv
#
#
# class   ModelPlotter:
#     def __init__(self, model):
#         """
#
#         Parameters
#         ----------
#         model
#         """
#         self.model = model
#
#     def